// Campus Info Hub - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
  const resourcesList = document.getElementById('resources-list');
  const tagsDisplay = document.getElementById('tags-display');

  // Load resources from JSON (relative URL)
  fetch('data/resources.json')
    .then(response => response.json())
    .then(data => {
      const resources = data.resources;
      displayResources(resources);
      displayTags(resources);
      setupFilters(resources);
    })
    .catch(err => {
      resourcesList.innerHTML = '<p class="card">Eroare la încărcarea datelor.</p>';
      console.error(err);
    });

  function displayResources(resources) {
    if (!resourcesList) return;
    resourcesList.innerHTML = '<div class="card-grid">' + resources.map(r => `
      <div class="card" data-tags="${r.tags.join(' ')}">
        <h3>${r.name}</h3>
        <div class="card-meta">
          <span>📍 ${r.location}</span>
          <span>🕐 ${r.program}</span>
        </div>
        <div class="tags">${r.tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>
      </div>
    `).join('') + '</div>';
  }

  function displayTags(resources) {
    if (!tagsDisplay) return;
    const allTags = [...new Set(resources.flatMap(r => r.tags))];
    tagsDisplay.innerHTML = '<div class="tags">' + 
      allTags.map(t => `<span class="tag">${t}</span>`).join('') + '</div>';
  }

  function setupFilters(resources) {
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach(btn => {
      btn.addEventListener('click', function() {
        buttons.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const filter = this.dataset.filter;
        const filtered = filter === 'all' ? resources : 
          resources.filter(r => r.tags.includes(filter) || r.type === filter);
        displayResources(filtered);
      });
    });
  }
});
