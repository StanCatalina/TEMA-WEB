# Campus Info Hub

Un site informațional pentru campus universitar, cu resurse despre bibliotecă, cantină și evenimente.

## Structură

- `index.html` - Pagina principală
- `pages/library.html` - Biblioteca
- `pages/cafeteria.html` - Cantina
- `pages/events.html` - Evenimente
- `data/resources.json` - Date despre resurse
- `js/main.js` - Script pentru încărcare dinamică
- `css/style.css` - Stiluri

## Întrebări

### 1. Ce este o resursă (resource) în aplicația ta?

O **resursă** este un loc sau serviciu din campus care oferă studenților facilități utile. Exemple: Biblioteca Centrală, Cantina Universitară, Sala de Lectură, Cafenea Studențească, Sala de Evenimente. Fiecare resursă are: nume, tip, locație, program și tag-uri care o descriu.

### 2. Da exemplu de un URI și explică componentele acestuia.

**Exemplu:** `https://example.com/pages/library.html#schedule`

- **Scheme:** `https:` – protocolul de comunicare
- **Host:** `example.com` – domeniul serverului
- **Path:** `/pages/library.html` – calea către fișierul HTML al bibliotecii
- **Fragment:** `#schedule` – identificator care indică secțiunea "Program" din pagină

### 3. Care părți sunt statice și care sunt dinamice?

**Statice:**
- Paginile `library.html`, `cafeteria.html`, `events.html` – conținutul HTML este fix
- Structura navigației, layout-ul, stilurile CSS

**Dinamice:**
- Pagina `index.html` – lista de resurse, tag-urile și filtrele sunt încărcate și afișate dinamic prin JavaScript folosind `fetch` pentru `data/resources.json`
- Conținutul listei și al secțiunii de tag-uri se actualizează în funcție de datele din JSON și de filtrele selectate

### 4. Este aplicația ta document-centric sau interactive (sau ambele)? De ce?

**Ambele.**

- **Document-centric:** Paginile Biblioteca, Cantina și Evenimente sunt documente statice care prezintă informații fixe. Utilizatorul le citește fără a modifica conținutul.

- **Interactive:** Pagina principală permite interacțiune: utilizatorul poate filtra resursele (Toate, Studiu, Mâncare, Evenimente). JavaScript încarcă datele din JSON și actualizează DOM-ul în funcție de selecție, fără reîncărcarea paginii.
