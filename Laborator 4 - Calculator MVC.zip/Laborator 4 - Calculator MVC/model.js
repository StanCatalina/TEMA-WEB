class Model {
    constructor() {
        this.reset();
    }

    reset() {
        this.displayValue = '0';
        this.operand1 = null;
        this.operator = null;
        this.waitingForOperand2 = false;
        this.expression = '';
    }

    updateDisplay(digit) {
        if (this.waitingForOperand2) {
            this.displayValue = digit;
            this.waitingForOperand2 = false;
        } else {
            this.displayValue = this.displayValue === '0' ? digit : this.displayValue + digit;
        }
    }

    setOperator(nextOperator) {
        const inputValue = parseFloat(this.displayValue);

        if (this.operand1 === null) {
            this.operand1 = inputValue;
        } else if (this.operator) {
            const result = this.calculate();
            this.displayValue = String(result);
            this.operand1 = result;
        }

        this.operator = nextOperator;
        this.waitingForOperand2 = true;
        this.expression = `${this.operand1} ${this.operator}`;
    }

    calculate() {
        const val1 = this.operand1;
        const val2 = parseFloat(this.displayValue);
        
        if (this.operator === '+') return val1 + val2;
        if (this.operator === '-') return val1 - val2;
        if (this.operator === '*') return val1 * val2;
        if (this.operator === '/') {
            return val2 === 0 ? "Eroare: / 0" : val1 / val2;
        }
        return val2;
    }

    getResult() {
        const result = this.calculate();
        this.expression = '';
        this.displayValue = String(result);
        this.operand1 = null;
        this.operator = null;
        this.waitingForOperand2 = false;
    }
}