class Controller {
    constructor(model, view) {
        this.model = model;
        this.view = view;

        // Pasăm acțiunea către Model și apoi randăm View-ul
        this.view.bindButtonClick(this.handleInput);
    }

    handleInput = (value) => {
        if (!isNaN(value)) {
            this.model.updateDisplay(value);
        } else if (value === 'AC') {
            this.model.reset();
        } else if (value === '=') {
            this.model.getResult();
        } else {
            this.model.setOperator(value);
        }

        // După orice modificare în Model, actualizăm interfața
        this.view.render(this.model);
    }
}