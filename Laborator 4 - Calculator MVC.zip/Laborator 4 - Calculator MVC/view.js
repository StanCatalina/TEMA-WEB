class View {
    constructor() {
        this.app = document.getElementById('calculator');
        this.initLayout();
        this.displayExp = document.getElementById('current-exp');
        this.displayRes = document.getElementById('result');
    }

    initLayout() {
        this.app.innerHTML = `
            <div class="display">
                <div id="current-exp"></div>
                <div id="result">0</div>
            </div>
            <div class="buttons">
                <button class="clear" data-val="AC">AC</button>
                <button class="operator" data-val="/">/</button>
                <button class="operator" data-val="*">*</button>
                <button data-val="7">7</button><button data-val="8">8</button><button data-val="9">9</button>
                <button class="operator" data-val="-">-</button>
                <button data-val="4">4</button><button data-val="5">5</button><button data-val="6">6</button>
                <button class="operator" data-val="+">+</button>
                <button data-val="1">1</button><button data-val="2">2</button><button data-val="3">3</button>
                <button class="equals" data-val="=">=</button>
                <button data-val="0">0</button>
            </div>
        `;
    }

    render(model) {
        this.displayRes.innerText = model.displayValue;
        this.displayExp.innerText = model.expression;
    }

    bindButtonClick(handler) {
        this.app.addEventListener('click', e => {
            if (e.target.tagName === 'BUTTON') {
                handler(e.target.dataset.val);
            }
        });
    }
}