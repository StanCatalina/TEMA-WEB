# Laborator 3 - Răspunsuri Teoretice

## 1.1 Întrebări Teoretice

**1. Care sunt cele 4 metode HTTP principale și când se folosește fiecare?**
- **GET**: Folosită pentru a solicita și prelua date (resurse) de la un server. Este metoda implicită când accesăm un URL în browser web. Nu ar trebui să fie folosită pentru operațiuni care modifică datele pe server.
- **POST**: Folosită pentru a trimite date către server pentru a crea o resursă nouă (de exemplu, trimiterea datelor dintr-un formular de înregistrare, login). Datele sunt incluse în corpul cererii (`body`).
- **PUT**: Folosită pentru a actualiza sau înlocui o resursă existentă pe server cu datele noi trimise în cerere.
- **DELETE**: Folosită pentru a șterge o resursă specificată de pe server.

**2. Ce semnifică codurile de status: 200, 301, 400, 401, 403, 404, 500?**
- **200 OK**: Cererea a fost procesată cu succes, iar serverul a returnat datele solicitate.
- **301 Moved Permanently**: Resursa accesată a fost mutată permanent la un alt URL. Browserul va redirecta automat către noua adresă.
- **400 Bad Request**: Serverul nu poate procesa cererea din cauza unei erori din partea clientului (sintaxă invalidă, parametri incorecți etc.).
- **401 Unauthorized**: Cererea necesită autentificare. Clientul trebuie să se autentifice pentru a obține un răspuns (ex. lipsă token sau credențiale incorecte).
- **403 Forbidden**: Clientul este refuzat direct, chiar dacă s-a autentificat. Accesul la resursa respectivă îi este strict interzis din cauza lipsei permisiunilor.
- **404 Not Found**: Serverul nu a putut găsi resursa solicitată la adresa URL furnizată.
- **500 Internal Server Error**: O eroare neașteptată a apărut pe server în timpul procesării cererii. Este o eroare de server (ex. o excepție neprinsă în codul backend-ului).

**3. Care este diferența între HTTP și HTTPS?**
- **HTTP (HyperText Transfer Protocol)** este protocolul de bază prin care sunt transferate datele între browser și server. Datele sunt trimise în text clar ("plain text"), ceea ce le face vulnerabile la interceptare (atacuri de tip Man-In-The-Middle).
- **HTTPS (HyperText Transfer Protocol Secure)** este o extensie securizată a HTTP. Utilizează criptarea prin protocoalele TLS/SSL pentru a securiza comunicația. Acest lucru asigură confidențialitatea și integritatea datelor, prevenind ascultarea și manipularea acestora în tranzit (esențial pentru tranzacții financiare, autentificare etc.).
